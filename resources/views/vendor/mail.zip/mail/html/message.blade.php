@component('mail::layout')
{{-- Header --}}
@slot('header')
@component('mail::header', ['url' => config('app.url')])
<a href="https://schoolmanagement.webbazaardevelopment.com" style="flex-direction: column;
display: flex;
align-items: center;
justify-content: center;">
<img src="https://schoolmanagement.webbazaardevelopment.com/school/profiles/1748204780466456.png" class="logo" alt="Laravel Logo">
{{isset(Configurations::getConfig('site')->school_name) ? Configurations::getConfig('site')->school_name : 'S-Management' }}
</a>

@endcomponent
@endslot

{{-- Body --}}
{{ $slot }}

{{-- Subcopy --}}
@isset($subcopy)
@slot('subcopy')
@component('mail::subcopy')
{{ $subcopy }}
@endcomponent
@endslot
@endisset

{{-- Footer --}}
@slot('footer')
@component('mail::footer')
© {{ date('Y') }} {{isset(Configurations::getConfig('site')->school_name) ? Configurations::getConfig('site')->school_name : '' }}  @lang('All rights reserved.')
@endcomponent
@endslot
@endcomponent
